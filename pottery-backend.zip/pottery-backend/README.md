# Clay & Kiln booking backend

This is a real server for your pottery site. It replaces the Google Form
workaround with actual one-click checkout: a customer picks a class, pays
with card / Apple Pay / Google Pay on Stripe's own secure payment page, and
the instant payment succeeds, the booking is written into your Google Sheet
automatically. No second tab, no manual step.

You (or a developer) need to do a few one-time setup steps below. None of
this can be done for you by an AI assistant, because it involves your own
financial accounts and passwords.

## What you'll need

1. A **Stripe account** (free to create, takes a cut only when you get paid) — this is what actually processes the payment.
2. A **Google service account** (free) — a robot account that's allowed to write to one specific Google Sheet, nothing else.
3. A place to host the server — these instructions use **Render.com** (free tier works fine to start).

## 1. Create your Stripe account

1. Go to https://dashboard.stripe.com/register and sign up with your business email.
2. You can build and test everything in **Test mode** (toggle in the top right of the Stripe dashboard) before ever handling real money.
3. Go to **Developers → API keys**. Copy the **Secret key** (starts with `sk_test_...`). You'll paste this in as `STRIPE_SECRET_KEY`.
4. Apple Pay and Google Pay show up automatically on Stripe's checkout page for eligible customers — no extra setup needed for those. If you also want bank transfers or PayPal, turn them on under **Settings → Payment methods** in the Stripe dashboard.
5. When you're ready to take real payments, flip to **Live mode** and repeat step 3 for your live secret key, and complete Stripe's business verification (bank account, business details) directly on stripe.com.

## 2. Create the Stripe webhook (tells your server "payment succeeded")

1. In the Stripe dashboard: **Developers → Webhooks → Add endpoint**.
2. Endpoint URL: `https://YOUR-DEPLOYED-URL/api/webhook` (you'll get this URL after step 4 below — you can come back and set this after deploying).
3. Select the event `checkout.session.completed`.
4. After creating it, click into the webhook and copy the **Signing secret** (starts with `whsec_...`). This becomes `STRIPE_WEBHOOK_SECRET`.

## 3. Google Sheet setup (so bookings write themselves in)

1. Go to https://console.cloud.google.com/ and create a new project (or use an existing one).
2. Go to **APIs & Services → Library**, search for "Google Sheets API", and enable it.
3. Go to **APIs & Services → Credentials → Create Credentials → Service account**. Give it any name (e.g. "clay-kiln-booking-bot").
4. Open the service account you just made → **Keys → Add key → Create new key → JSON**. This downloads a `.json` file — keep it private, like a password.
5. Open that JSON file in a text editor, and copy its ENTIRE contents as one line into `GOOGLE_SERVICE_ACCOUNT_JSON` in your environment variables.
6. Open your existing "Clay & Kiln Sign-Ups" Google Sheet. Click **Share**, and share it with the service account's email address (it looks like `something@your-project.iam.gserviceaccount.com` — found in the JSON file as `client_email`), giving it **Editor** access.
7. In that Sheet, add a new tab named `Bookings` with headers in row 1: `Date | Name | Email | Class | Amount | Payment Method | Status`. (Keep your existing Form-response tab too if you like — this just writes to a separate, cleaner tab for real paid bookings.)
8. Copy the Sheet's ID from its URL — the long string between `/d/` and `/edit` — into `GOOGLE_SHEET_ID`.

## 4. Deploy the server (Render.com, free to start)

1. Put this folder in its own GitHub repository (ask a developer or use GitHub Desktop if you're not familiar with git).
2. Go to https://render.com, sign up, click **New → Web Service**, and connect that repository.
3. Build command: `npm install` — Start command: `npm start`.
4. Under **Environment**, add every variable from `.env.example` with your real values (Stripe keys, the Google service account JSON, your sheet ID, etc). Set `PUBLIC_URL` to the `https://your-app-name.onrender.com` address Render gives you.
5. Deploy. Once it's live, go back to step 2 above and finish setting up the Stripe webhook with your real live URL.

## 5. Point your site's domain here

Once this is deployed and working, this becomes your real pottery website —
it already serves the full site (classes, booking, payment) from
`public/index.html`. If you bought a domain like `clayandkiln.com`, point it
at this Render service instead of the old demo page (Render's dashboard has
a "Custom Domain" setting that walks you through it).

## Testing before going live

- Keep Stripe in **Test mode** and use its test card `4242 4242 4242 4242`,
  any future expiry date, and any 3-digit CVC — this simulates a real
  payment without charging anyone.
- Check that a row appears in your Sheet's `Bookings` tab after a test
  payment.
- Only switch to your Stripe **Live** keys once that all works.

## If something doesn't write to the Sheet

Payment always succeeds or fails independently of the Sheet write — a
customer is never charged twice or left unpaid because of a Sheet problem.
If the Sheet write fails (wrong sharing permission, wrong tab name), it's
logged in Render's **Logs** tab with the customer's email and class, so you
can add them manually and fix the setup for next time.
